# TechnoHacks_Task1
Task 1 : Perform Data Cleaning in titanic Dataset, Here i ve removed missing values and outliers using IQR 
Also visualize the missing values and outliers and did comparsion between them.
